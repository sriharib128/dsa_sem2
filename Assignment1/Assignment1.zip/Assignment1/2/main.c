#include "complex.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main()
{
    int N;
    char TYPE[50];
    scanf("%s %d", TYPE, &N);
    if (strcmp(TYPE, "DOT") != 0 && strcmp(TYPE, "MOD") != 0)
    {
        struct Complex a, b;
        a.entry = (float *)malloc(N * sizeof(float));
        b.entry = (float *)malloc(N * sizeof(float));
        a.n = N;
        b.n = N;
        for (int i = 0; i < N; i++)
            scanf("%f", &(a.entry[i]));
        for (int i = 0; i < N; i++)
            scanf("%f", &(b.entry[i]));
        if (strcmp(TYPE, "ADD") == 0)
        {
            struct Complex c = add(a, b);
            print(c);
        }
        if (strcmp(TYPE, "SUB") == 0){
            struct Complex c=sub(a, b);
            print(c);
        }
        if (strcmp(TYPE, "COS") == 0)
        {
            float c=Cos(a, b);
            printf("%0.2f",c);
        }
    }
    if (strcmp(TYPE, "MOD") == 0)
    {
        struct Complex a;
        a.entry = (float *)malloc(N * sizeof(float));
        a.n = N;
        for (int i = 0; i < N; i++)
            scanf("%f", &(a.entry[i]));
        float m = mod(a);
        printf("%0.2f", m);
    }
    if (strcmp(TYPE, "DOT") == 0)
    {
        struct Complex a, b;
        a.entry = (float *)malloc(N * sizeof(float));
        b.entry = (float *)malloc(N * sizeof(float));
        a.n = N;
        for (int i = 0; i < N; i++)
            scanf("%f", &(a.entry[i]));
        for (int i = 0; i < N; i++)
            scanf("%f", &(b.entry[i]));
        printf("%0.2f", dot(a, b));
    }
}
