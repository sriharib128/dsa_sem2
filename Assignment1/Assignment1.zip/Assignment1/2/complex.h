#ifndef _COMPLEX_H
#define _COMPLEX_H
typedef struct Complex* complex;

struct Complex{
    int n;
    float *entry;
};

struct Complex add(struct Complex A, struct Complex B);
struct Complex sub(struct Complex A, struct Complex B);
float mod(struct Complex A);
float dot(struct Complex A, struct Complex B);
float Cos(struct Complex A, struct Complex B);
void print(struct Complex A);

#endif