#include"my_dll.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <assert.h>

int main()
{
    dll list=createlist();
    char s[50];
    int num;
start:
    scanf("%s",s);
    if(strcmp("insert",s)==0){
        scanf("%d",&num);
        insert(list, num);
    }
    if(strcmp("insert_at",s)==0){
        int position;
        scanf("%d",&num);
        scanf("%d",&position);
        insert_at(list, num, position);
    }
    if(strcmp("delete",s)==0){
        scanf("%d",&num);
        delete(list, num);
    }
    if(strcmp("find",s)==0){
        scanf("%d",&num);
        find(list, num);
    }
    if(strcmp("prune",s)==0){
        prune(list);
    }
    if(strcmp("print",s)==0){
        print(list);
    }
    if(strcmp("print_reverse",s)==0){
        print_reverse(list);
    }
    if(strcmp("getsize",s)==0){
        getsize(list);
    }
    if(strcmp("exit",s)==0){
      goto further;
    }
    goto start;
further:
    exit(0);
}/*
    insert(list, 1);
    insert(list, 2);
    insert_at(list, 3, 1);
    print(list);
    print_reverse(list);
    insert(list, 4);
    insert(list, 5);
    insert(list, 6);
    print(list);
    prune(list);
    print(list);
    */