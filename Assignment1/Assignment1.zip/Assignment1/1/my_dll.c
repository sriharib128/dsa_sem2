#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "my_dll.h"
#include "node.h"

dll createlist()
{
    dll list = (dll)malloc(sizeof(struct dll));
    list->root = NULL;
    return list;
}
void insert(dll list, int x)
{
    Node new_node = newNode(x);
    if (list->root == NULL)
    {
        new_node->prev = NULL;
        new_node->next = NULL;
        list->root = new_node;
        return;
    }
    else
    {
        Node temp = list->root;
        while (temp->next != NULL)
        {
            temp = temp->next;
        }
        temp->next = new_node;
        new_node->prev = temp;
        new_node->next = NULL;
    }
}

void insert_at(dll list, int x, int i)
{
    Node ptr = (Node)malloc(sizeof(struct node));
    assert(ptr != NULL);
    Node temp;
    temp = list->root;
    for (int j = 0; j < i - 1; j++)
    {
        temp = temp->next;
    }
    ptr->data = x;
    ptr->next = temp->next;
    ptr->prev = temp;
    temp->next->prev = ptr;
    temp->next = ptr;
}

void delete(dll list, int i)
{
    if (list->root == NULL)
    {
        return;
    }
    Node del;
    del= list->root;
    if(i==0){
        del->next->prev=NULL;
    }
    for (int j = 0; j < i; j++)
    {
        del = del->next;
    }
    if (list->root == del)
    {
        list->root = del->next;
    }
    if (del->next != NULL)
    {
        del->next->prev = del->prev;
    }
    if (del->prev != NULL)
    {
        del->prev->next = del->next;
    }
    free(del);
    return;
}
void prune(dll list)
{
    Node temp = list->root;
    if (list->root != NULL)
    {
        list->root->prev = NULL;
        Node evenNode = list->root;
        Node oddNode = list->root->next;
        while (evenNode != NULL && oddNode != NULL)
        {
            evenNode->next = oddNode->next;
            free(oddNode);
            temp = evenNode;
            evenNode = evenNode->next;
            if (evenNode != NULL)
            {
                evenNode->prev = temp;
                oddNode = evenNode->next;
            }
        }
    }
}

void find(dll list, int x)
{
    Node temp = list->root;
    int count = 0, flag = 0;
    while (temp != NULL)
    {
        if (temp->data == x)
        {
            printf("%d\n", count);
            flag = 1;
            break;
        }

        count++;
        temp = temp->next;
    }
    if (flag == 0)
        printf("%d", -1);
}

void print(dll list)
{
    Node temp = list->root;
    while (temp != NULL)
    {
        printf("%d\n", temp->data);
        temp = temp->next;
    }
}

void print_reverse(dll list)
{
    Node temp = list->root;
    while (temp->next != NULL)
    {
        temp = temp->next;
    }
    Node ptr;
    ptr = temp;
    while (1)
    {
        printf("%d\n", ptr->data);
        if (ptr->prev == NULL)
            break;
        ptr = ptr->prev;
    }
}

int getsize(dll list)
{
    Node temp = list->root;
    int count = 0;
    while (temp != NULL)
    {
        count++;
        temp = temp->next;
    }
    return count;
}
