# DSA ASSIGNMENT 1

## How to Run the Project
* Prerequisite
    * Software: C.
    * Operating System: Linux based.
### 1:Doubly Linked List 
* For question 1, Please execute the following command: 
    ```
    gcc main.c my_dll.c node.c
    ./a.out
    ```
###2:Complex Number ADT
* For question 2, Please execute the following command:
    ```
    gcc main.c complex.c
    ./a.out
    ```
### 3:
* For question 3, Please execute the following command:
    ```
    gcc main.c music_player.c song.c
    ./a.out
