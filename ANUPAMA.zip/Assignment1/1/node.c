#include"node.h"

#include<stdio.h>
#include<stdlib.h>

Node newNode(int num)
{
    Node new_node= malloc(sizeof(struct node));
    new_node->data = num;
    new_node->next = NULL;
    new_node->prev=NULL;
    return new_node;
}
