#ifndef NODE_H
#define NODE_H

struct node
{
    int data;
    struct node *next;
    struct node *prev;
};
typedef struct node* Node;
Node head;

Node newNode(int num);

#endif