#include "node.h"
#ifndef _DLL_H
#define _DLL_H

typedef struct dll* dll;
struct dll{
    Node root;
};

dll createlist();
void insert(dll list, int x);
void insert_at(dll list, int x, int i);
void delete(dll list, int i);
void find(dll list, int x);
void prune(dll list);
void print(dll list);
void print_reverse(dll list);
int getsize(dll list);

#endif