#include "musicplayer.h"
#include <stdio.h>
#include <stdlib.h>

MusicPlayer createMusicPlayer()
{
    MusicPlayer Music_Player = (struct MusicPlayer *)malloc(sizeof(struct MusicPlayer));
    // Music_Player->Queue = (struct Queue *)malloc(sizeof(struct Queue));
    // Music_Player->Queue->data = (struct song *)malloc(sizeof(struct song));
    Music_Player->Queue= NULL;
    Music_Player->currentsong = NULL;
    return Music_Player;
}
struct Queue *createQueue(Song song)
{
    struct Queue *new_Queue = (struct Queue *)malloc(sizeof(struct Queue));
    new_Queue->data = song;
    new_Queue->next = NULL;
    return new_Queue;
}
int addSongToQueue(MusicPlayer Music_Player, Song song)
{
    struct Queue *prev = Music_Player->Queue;
    struct Queue *new_Queue = createQueue(song);
    if (Music_Player->Queue == NULL)
    {   
        Music_Player->Queue = new_Queue;
        // Music_Player->currentsong = new_Queue->data;
        return 0;
    }
    else
    {
        while (prev->next != NULL)
        {
            prev = prev->next;
        }
        prev->next = new_Queue;
        return 0;
    }
    return 1;
}
void print(MusicPlayer Music_player)
{
    struct Queue *temp = Music_player->Queue->start;
    while (temp != NULL)
    {
        printf("%s\n", temp->data->Song);
        temp = temp->next;
    }
}

int removeSongFromQueue(MusicPlayer Music_Player, int song_num)
{  
    struct Queue *del = Music_Player->Queue;
    if(del==NULL)
        return 1;

    struct Queue *prev;

    if (song_num == 0)
    {   
        if(del->next!=NULL)
            Music_Player->Queue = del->next;
        if(del->next==NULL)
            Music_Player->Queue = NULL;
        return 0;
    }
    
    if (song_num != 0)
    {
        for (int j = 0; j < song_num-1; j++)
        {
            del = del->next;
        }
        if (del->next != NULL)
        {
            del->next = del->next->next;
        }
        else
            del->next=NULL;
        // free(del);
        return 0;
    }
    return 1;
}
int playSong(MusicPlayer Music_Player)
{   

    if(Music_Player->Queue ==NULL)
        return 1;

    Song temp = Music_Player->Queue->data;

    Music_Player->currentsong=makeSong(temp->Song,temp->Artist,temp->Duration);

    removeSongFromQueue(Music_Player,0);
    return 0;
}
Song getCurrentSong(MusicPlayer Music_Player)
{
    Song CURRENT = (struct song *)malloc(sizeof(struct song));
    CURRENT = Music_Player->currentsong;
    // Music_Player->currentsong = makeSong();
    // removeSongFromQueue(Music_Player, 0);
    return CURRENT;
}