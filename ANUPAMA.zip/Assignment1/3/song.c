#include"song.h"
#include<string.h>
#include<stdlib.h>

Song makeSong(char *song_name, char *artist, float duration){
    Song newsong;
    newsong=(Song) malloc(sizeof (struct song));
    newsong->Song=(char*) malloc(100*sizeof(char));
    strcpy(newsong->Song,song_name);
    newsong->Artist=(char*) malloc( 100*sizeof(char));
    strcpy(newsong->Artist,artist);
    newsong->Duration=duration;
    return newsong;
}