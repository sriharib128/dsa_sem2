#ifndef _SONG_H
#define _SONG_H

typedef struct song* Song;
struct song{
    char *Song;
    char *Artist;
    float Duration;
};

Song makeSong(char *song, char *artist, float duration);
#endif