#include "song.h"
#ifndef _MUSIC_H
#define _MUSIC_H

typedef struct MusicPlayer *MusicPlayer; 
struct Queue{
    struct song *data;
    struct Queue *start;
    struct Queue *next;
};
struct MusicPlayer
{
    struct song* currentsong;
    struct Queue *Queue;
};

MusicPlayer createMusicPlayer();
struct Queue* createQueue(Song song);
int addSongToQueue(MusicPlayer, Song song);
int removeSongFromQueue(MusicPlayer, int song_num);
int playSong(MusicPlayer);
Song getCurrentSong(MusicPlayer);
void print(MusicPlayer Music_player);

#endif