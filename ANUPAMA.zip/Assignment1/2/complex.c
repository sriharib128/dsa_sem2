#include"complex.h"
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
struct Complex add(struct Complex A, struct Complex B){
    int N = A.n;
    struct Complex c;
    c.n=A.n;
    c.entry=(float*)malloc(N*sizeof(float));
    for(int i=0;i<N;i++){
        c.entry[i]=A.entry[i]+B.entry[i];
    }
    return c;
}
struct Complex sub(struct Complex A, struct Complex B){
    int N= A.n;
    struct Complex c;
    c.n=A.n;
    c.entry=(float*)malloc(N*sizeof(float));
    for(int i=0;i<N;i++){
        c.entry[i]=A.entry[i]-B.entry[i];
    }
    return c;
}
float mod(struct Complex A){
    int N= A.n;
    float mod=0;
    for(int i=0;i<N;i++){
        mod=(A.entry[i] * A.entry[i]) + mod;
    }
    mod=sqrt(mod);
    return mod;
}
float dot(struct Complex A, struct Complex B){
    int N= A.n;
    float dot=0;
    for(int i=0;i<N;i++){
        dot=(A.entry[i]*B.entry[i])+dot;
    }
    return dot;
}
float Cos(struct Complex a, struct Complex b){
    float x;
    x=dot(a, b)/(mod(a)*mod(b));
    return x;
}
void print(struct Complex A){
    int N= A.n;
    for(int i=0;i<N;i++){
        printf("%0.2f ",A.entry[i]);
    }
}